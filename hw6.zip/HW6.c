//Melina Marandi 
//40223074
#include <math.h>
#include <stdio.h>

void  solver (double a,double b,double c,double *,double*);
        
int main ()
{
double A,B,C;
double x3,x4;
double *p1=&x3;
double *p2=&x4;
*p1=12;
*p2=13;
printf("Enter 3 numbers\n");
scanf("%lf%lf%lf",&A,&B,&C);

solver(A,B,C,p1,p2);
printf(" the one root is : %lf\n   ",*p1);
printf(" another root is : %lf\n   ",*p2);

}
void  solver (double a,double b,double c, double *rishe1,double *rishe2) {
    //Declare variables
    double  delta, root1, root2 ;
    
      delta = b * b - 4 * a * c;
      // Conditions for the roots 
    if (delta > 0) {
        root1 = (-b + sqrt(delta)) / (2 * a);
        root2 = (-b - sqrt(delta)) / (2 * a);
       *rishe1 =root1;
        *rishe2=root2;
    
        
    }
    else if (delta == 0) {
        root1 = root2 = -b / (2 * a);
       *rishe1=*rishe2=root1;
    }
    else {
       
       printf("this equation has no roots");
    }
}
